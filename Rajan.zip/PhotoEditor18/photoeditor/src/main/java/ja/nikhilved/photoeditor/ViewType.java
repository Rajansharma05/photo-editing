package ja.nikhilved.photoeditor;



public enum ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}
