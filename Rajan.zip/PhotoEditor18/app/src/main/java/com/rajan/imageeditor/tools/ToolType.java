package com.rajan.imageeditor.tools;


public enum ToolType {
    BRUSH,
    TEXT,
    ERASER,
    FILTER,
    EMOJI,
    STICKER
}
